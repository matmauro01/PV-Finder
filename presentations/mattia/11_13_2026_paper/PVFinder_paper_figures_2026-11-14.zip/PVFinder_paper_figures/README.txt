PV-Finder paper figures, 14 Nov 2026 (the same files as PVFinder_paper_deck_2026-11-13.pdf).
Final configuration: test set r16443 entries 0-24,999, 0.17 mm window (HS 0.1 mm), GNN v2 at t = 0.94, vertices with >= 2 tracks.
Badge: PAPER MAIN = proposed for the paper; BACKUP/NOTE = for the note or backup.

file | slide | badge
mu_training.pdf | HL-LHC Density Model: Training, Validation and Test | 
mu_validation.pdf | HL-LHC Density Model: Training, Validation and Test | 
mu_test.pdf | HL-LHC Density Model: Training, Validation and Test | 
mu_r16443.pdf | HL-LHC Held-out Files and the GNN v2 Samples | 
mu_r16638.pdf | HL-LHC Held-out Files and the GNN v2 Samples | 
lowpu_mu.pdf | Low Pile-up Samples | 
eff_vs_mu.pdf | HL-LHC before the GNN: Efficiency and Fakes versus mu | PAPER MAIN
fake_fraction_vs_mu.pdf | HL-LHC before the GNN: Efficiency and Fakes versus mu | PAPER MAIN
fakes_per_event_vs_mu.pdf | HL-LHC before the GNN: Fakes and Yield versus mu | PAPER MAIN
eff_one_to_one_vs_mu.pdf | HL-LHC before the GNN: Backup | BACKUP/NOTE
splits_per_event_vs_mu.pdf | HL-LHC before the GNN: Backup | BACKUP/NOTE
yield_vs_mu.pdf | HL-LHC before the GNN: Fakes and Yield versus mu | PAPER MAIN
deltaz_pu200.pdf | HL-LHC before the GNN: Vertex Separation and Position at PU200 | PAPER MAIN
residuals_pu200.pdf | HL-LHC before the GNN: Vertex Separation and Position at PU200 | PAPER MAIN
window_justification.pdf | HL-LHC before the GNN: Window Justification and Scan | 
window_scan.pdf | HL-LHC before the GNN: Window Justification and Scan | PAPER MAIN
p68_vs_mu.pdf | HL-LHC before the GNN: Resolution versus mu | PAPER MAIN
hs_reco_vs_mu.pdf | HL-LHC before the GNN: Hard-Scatter Reconstruction | PAPER MAIN
eff_ntrk_pre_pu200.pdf | HL-LHC before the GNN: Efficiency vs n_mathrmtrk, Density, Separation (Backup) | BACKUP/NOTE
eff_density_pre_pu200.pdf | HL-LHC before the GNN: Efficiency vs n_mathrmtrk, Density, Separation (Backup) | BACKUP/NOTE
eff_dz_pre_pu200.pdf | HL-LHC before the GNN: Efficiency vs n_mathrmtrk, Density, Separation (Backup) | BACKUP/NOTE
clean_yield_paper.pdf | HL-LHC after the GNN: Clean/truth by Association Method | PAPER MAIN
clean_yield_mu_paper.pdf | HL-LHC after the GNN: Clean/truth by Association Method | PAPER MAIN
classes_pu200.pdf | HL-LHC after the GNN: Pile-up Vertex Quality at PU200 | PAPER MAIN
clean_evt_vs_mu.pdf | HL-LHC after the GNN: Vertex Categories versus mu | PAPER MAIN
merged_evt_vs_mu.pdf | HL-LHC after the GNN: Vertex Categories versus mu | PAPER MAIN
split_evt_vs_mu.pdf | HL-LHC after the GNN: Vertex Categories versus mu | PAPER MAIN
fake_evt_vs_mu.pdf | HL-LHC after the GNN: Vertex Categories versus mu | PAPER MAIN
clean_truth_vs_mu.pdf | HL-LHC after the GNN: Clean/truth and Efficiency versus n_mathrmtrk | PAPER MAIN
hs_sel_vs_mu.pdf | HL-LHC after the GNN: Hard-Scatter Selection and Resolution | PAPER MAIN
hs_res_vs_mu.pdf | HL-LHC after the GNN: Hard-Scatter Selection and Resolution | PAPER MAIN
hs_reco_vs_density.pdf | HL-LHC after the GNN: Hard Scatter versus Local Pile-up Density | PAPER MAIN
hs_sel_vs_density.pdf | HL-LHC after the GNN: Hard Scatter versus Local Pile-up Density | PAPER MAIN
hs_res_vs_density.pdf | HL-LHC after the GNN: Hard Scatter versus Local Pile-up Density | PAPER MAIN
trk_f1_vs_mu.pdf | HL-LHC after the GNN: Track Association | 
trk_eff_vs_mu.pdf | HL-LHC after the GNN: Track Association | PAPER MAIN
trk_pur_vs_mu.pdf | HL-LHC after the GNN: Track Association | BACKUP/NOTE
eff_ntrk_post_pu200.pdf | HL-LHC after the GNN: Clean/truth and Efficiency versus n_mathrmtrk | PAPER MAIN
eff_density_post_pu200.pdf | HL-LHC after the GNN: Density, Separation, Peak Width (Backup) | BACKUP/NOTE
eff_dz_post_pu200.pdf | HL-LHC after the GNN: Density, Separation, Peak Width (Backup) | BACKUP/NOTE
hs_clean_vs_mu.pdf | HL-LHC after the GNN: Hard-Scatter Tracks, Density Definition (Backup) | BACKUP/NOTE
hs_trkfrac_vs_mu.pdf | HL-LHC after the GNN: Hard-Scatter Tracks, Density Definition (Backup) | BACKUP/NOTE
classes_variants.pdf | HL-LHC after the GNN: Classification Cross-checks (Backup) | BACKUP/NOTE
amvf_fit_weights.pdf | HL-LHC after the GNN: Classification Cross-checks (Backup) | BACKUP/NOTE
density_definitions.pdf | HL-LHC after the GNN: Hard-Scatter Tracks, Density Definition (Backup) | BACKUP/NOTE
eq4_vs_mu.pdf | HL-LHC after the GNN: One-to-one Bound and Eq.(4) (Backup) | BACKUP/NOTE
finder_cap_vs_mu.pdf | HL-LHC after the GNN: One-to-one Bound and Eq.(4) (Backup) | BACKUP/NOTE
stages_pu200.pdf | HL-LHC after the GNN: One-to-one Bound and Eq.(4) (Backup) | BACKUP/NOTE
wrong_rate_vs_mu.pdf | HL-LHC after the GNN: Unassigned and Wrong Tracks (Backup) | BACKUP/NOTE
lost_unassigned_vs_mu.pdf | HL-LHC after the GNN: Unassigned and Wrong Tracks (Backup) | BACKUP/NOTE
unlabelled_unassigned_vs_mu.pdf | HL-LHC after the GNN: Unassigned and Wrong Tracks (Backup) | BACKUP/NOTE
sigma_pv_pu200.pdf | HL-LHC after the GNN: Density, Separation, Peak Width (Backup) | BACKUP/NOTE
gnn_learning_curve.pdf | GNN v2: Learning Curve (Backup) | BACKUP/NOTE
lp_fig8a.pdf | Low Pile-up: Run 2 MC Vertex Finding (Fig.8) | PAPER MAIN
lp_fig8b.pdf | Low Pile-up: Run 2 MC Vertex Finding (Fig.8) | PAPER MAIN
lp_fig9a.pdf | Low Pile-up: Run 2 MC after the GNN (Table 5, Fig.9) | PAPER MAIN
lp_fig9b.pdf | Low Pile-up: Run 2 MC after the GNN (Table 5, Fig.9) | PAPER MAIN
lp_fig10a.pdf | Low Pile-up: Collision Data (Fig.10) | PAPER MAIN
lp_fig10b.pdf | Low Pile-up: Collision Data (Fig.10) | PAPER MAIN
lp_fig10c.pdf | Low Pile-up: Collision Data (Fig.10) | PAPER MAIN
lp_fig10d.pdf | Low Pile-up: Collision Data (Fig.10) | PAPER MAIN
lp_t_scan.pdf | Low Pile-up: Run 3 Data Association and the t Scan | BACKUP/NOTE
athena_timing.png | Timing: CPU and GPU | PAPER MAIN
